#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>

// this class is used to store the infomation of a certain product, and can update by trading info stream
class Stock {
public:
    std::string symbol;
    int totalVolume = 0;
    int maxPrice = -1;
    float averagePrice = 0;
    int lastTimeStamp = -1;
    int maxGap = 0;

    Stock() {}

    Stock(std::string symbol, int timeStamp, int volume, int price) {
        addTrade(symbol, timeStamp, volume, price);
    }

    ~Stock() {}

    void addTrade(std::string symbol, int timeStamp, int volume, int price) {
        this->symbol = symbol;
        totalVolume += volume;
        if (price > maxPrice) {
            maxPrice = price;
        }
        averagePrice = ((totalVolume - volume) * averagePrice + volume * price) / totalVolume;
        if (lastTimeStamp != -1 && (timeStamp - lastTimeStamp > maxGap)) {
            maxGap = timeStamp - lastTimeStamp;
        }
        lastTimeStamp = timeStamp;
    }

    std::vector<std::string> toStringVector(){
        std::vector<std::string> data = {symbol, std::to_string(maxGap), std::to_string(totalVolume), std::to_string((int)averagePrice), std::to_string(maxPrice)};
        return data;
    }

    friend std::ostream& operator<<(std::ostream& os, const Stock& stock) {
        os << "Total Volume: " << stock.totalVolume << "\n"
           << "Max Price: " << stock.maxPrice << "\n"
           << "Average Price: " << (int)stock.averagePrice << "\n"
           << "Max Gap: " << stock.maxGap;
        return os;
    }

    
};



int main() {
    std::map<std::string, Stock> stockMap = {};

    // 1. read the input as a stream and update stockMap by line
    std::ifstream file("input.csv");
    if (!file.is_open()) {
        std::cerr << "Error opening input file!" << std::endl;
        return 1;
    }

    std::string line;
    while (std::getline(file, line)) { 
        std::stringstream ss(line);    
        std::string cell;
        std::vector<std::string> row;

        while (std::getline(ss, cell, ',')) { 
            row.push_back(cell);              
        }
        if(stockMap.count(row[1]) == 0){
            Stock temp(row[1], std::stoi(row[0]), std::stoi(row[2]),std::stoi(row[3]));
            stockMap.insert(std::make_pair(row[1], temp));
        }else{
            stockMap[row[1]].addTrade(row[1], std::stoi(row[0]), std::stoi(row[2]),std::stoi(row[3]));
        }
    }
    for (const auto& pair : stockMap) {
        std::cout << pair.first << ": " << pair.second << std::endl << std::endl;

    }
    file.close(); 

    // 2. output the stockMap
    std::ofstream outFile("output.csv");
    if (!outFile) {
        std::cerr << "Error opening output file!" << std::endl;
        return 1;
    }
    outFile << "symbol,MaxTimeGap,Volume,WeightedAveragePrice,MaxPrice\n";

    std::vector<std::vector<std::string>> data = {};
    for (auto& pair : stockMap) {
        data.push_back(pair.second.toStringVector());
    }

    for (const auto& row : data) {
        for (size_t i = 0; i < row.size(); ++i) {
            outFile << row[i];
            if (i < row.size() - 1) {
                outFile << ","; 
            }
        }
        outFile << "\n"; 
    }

    outFile.close();

    std::cout << "CSV file has been written successfully." << std::endl;

    return 0;
}